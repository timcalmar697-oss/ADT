# Double Tracker (VST3) - Nachbildung des "Bell Automatic Double Tracker"

Verhaltensmodell der Schaltung mit den Bauteilwerten aus dem Schaltplan:
Eingangsstufe (LM741, Gain), NE571-Kompander mit Pre-/De-Emphasis, Anti-Aliasing- und
Rekonstruktionsfilter (je 2x Sallen-Key mit Transistor-Puffer), MN3005-BBD (4096 Stufen),
CD4046-VCO und LFO (LM741-Relaxationsoszillator), MIX-Poti.

## Regler

| Regler | Original | Wirkung |
|---|---|---|
| GAIN | A100K an U2 | Eingangsverstaerkung 1x bis 101x (+40 dB), Bandbreite sinkt mit GBW/Gain, asymmetrische Uebersteuerung |
| MIX | B100K | Ueberblendung Direktsignal <-> Delay |
| DELAY | A100K am CD4046 | Grundtakt des BBD, ca. 20 ms bis ueber 400 ms |
| DEV | B100K | Modulationstiefe (und leichte Verschiebung der Grundverzoegerung) |
| MOD | A100K am LFO | LFO-Rate, ca. 1 bis 35 Hz |
| LEVEL | nicht im Original | Ausgangspegel (-30 bis +12 dB), dazu eine weiche Begrenzung bei 0 dBFS |

Referenzpegel: 1,0 digital = 1 V. Bei GAIN-Stellung 0 ist die Verstaerkung 1.

## Plugin bauen (ohne lokale Entwicklungsumgebung)

1. Kostenloses Konto auf https://github.com anlegen.
2. Neues **privates** Repository anlegen (z. B. `double-tracker`).
3. Den kompletten Inhalt dieses Ordners hochladen (Schaltflaeche "Add file" > "Upload files",
   den Ordner `.github` nicht vergessen - versteckte Ordner ggf. per Drag & Drop mitziehen).
4. Im Repository auf den Reiter **Actions** gehen. Der Build startet automatisch (ca. 10 Minuten,
   beim ersten Mal wird JUCE geladen). Bei Bedarf "Build VST3 (Windows)" > "Run workflow".
5. Wenn der Lauf gruen ist: den Lauf oeffnen, unten unter **Artifacts** `DoubleTracker-VST3-Windows`
   herunterladen und entpacken.
6. Den Ordner `Double Tracker.vst3` nach `C:\Program Files\Common Files\VST3` kopieren.
7. In Cakewalk: **Edit > Preferences > Audio > Plug-in Settings**, den VST3-Pfad pruefen und
   **Scan** ausfuehren. Das Plugin erscheint als "Double Tracker" unter den VST3-Effekten.

Falls ein Lauf rot wird: die Fehlermeldung im Log kopieren und mir schicken.

## Eigenen Test der Rechenlogik (optional, Linux/macOS/WSL)

    g++ -O2 -std=c++17 -ISource test/dsp_test.cpp -o dsp_test && ./dsp_test

## Was gesichert ist und was geschaetzt

Gesichert durch Rechnung oder Test (siehe `test/dsp_test.cpp`):
- Filterkurven der Sallen-Key-Stufen (aus den R/C-Werten)
- LFO-Rate und Modulationsspannung am VCO-Eingang (gegen Vollsimulation mit Op-Amp-Modell)
- Delay-Zeit = 2048 / Taktfrequenz, gemessen gegen die Formel
- Kompander flach (+1,2 dB bei 1 kHz) ueber 50 dB Eingangspegel

**Geschaetzt bzw. nur aus dem Schaltplan gelesen** (hier liegt die Abweichung zum Original):
- VCO-Gesetz des CD4046 (Konstante k = 2,2, Streukapazitaet 32 pF): bestimmt die absolute Delay-Zeit
- Poti-Kennlinien (A = quadratisch angenommen)
- Gleichrichter-Zeitkonstanten des NE571 (3 ms / 10 ms), Pegelreferenz 0,775 Vrms
- De-Emphasis als R21/C21 in der Expander-Rueckkopplung (Lesart des Schaltplans)
- BBD-Rauschen (0,4 mV), Taktdurchschlag (1 mV), Eingangsuebersteuerung (4,5 V)
- Der Transistor-Block um Q1/Q2/Q3/Q5/D1-D3 (LED-Anzeige) ist nicht modelliert

Das Klangbild muss per Ohr gegen das Original abgeglichen werden. Die Konstanten stehen
oben in `Source/ADTDsp.h` und lassen sich dort anpassen.

## Lizenz

JUCE steht unter AGPLv3 bzw. einer kommerziellen/Personal-Lizenz von JUCE. Fuer reine
Eigennutzung unkritisch; vor einer Weitergabe oder einem Verkauf bitte die aktuellen
Bedingungen auf juce.com pruefen.
