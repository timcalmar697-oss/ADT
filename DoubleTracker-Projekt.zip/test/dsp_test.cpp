// Offline-Tests fuer ADTDsp.h  (g++ -O2 -std=c++17 -I../Source dsp_test.cpp -o dsp_test)
#include "ADTDsp.h"
#include <cstdio>
#include <complex>

using namespace adt;
static int failures = 0;
#define CHECK(cond, ...) do { if (!(cond)) { ++failures; std::printf("  FAIL: "); std::printf(__VA_ARGS__); std::printf("\n"); } } while (0)

static double rmsOf(const std::vector<double>& v, size_t a, size_t b)
{
    double s = 0; for (size_t i = a; i < b; ++i) s += v[i] * v[i];
    return std::sqrt(s / (double)(b - a));
}

// Betragsgang eines Biquads bei f
static double magBiquad(const Biquad& q, double f, double fs)
{
    const std::complex<double> z1 = std::polar(1.0, -2 * kPi * f / fs), z2 = z1 * z1;
    return std::abs((q.b0 + q.b1 * z1 + q.b2 * z2) / (1.0 + q.a1 * z1 + q.a2 * z2));
}

static void testFilters()
{
    std::printf("[1] Filter\n");
    const double fs = 96000;
    Biquad a, b;
    a.setSallenKey(33e3, 33e3, 660e-12, 220e-12, fs);
    b.setSallenKey(33e3, 33e3, 330e-12, 220e-12, fs);
    std::printf("  SK1: |H(100Hz)|=%.3f |H(12.66k)|=%.3f (Soll Q=0.866)\n", magBiquad(a, 100, fs), magBiquad(a, 12660, fs));
    std::printf("  SK2: |H(100Hz)|=%.3f |H(17.9k)|=%.3f (Soll Q=0.611)\n", magBiquad(b, 100, fs), magBiquad(b, 17900, fs));
    CHECK(std::fabs(magBiquad(a, 100, fs) - 1.0) < 0.01, "SK1 Durchlass");
    CHECK(std::fabs(magBiquad(a, 12660, fs) - 0.866) < 0.03, "SK1 Q");
    CHECK(std::fabs(magBiquad(b, 17900, fs) - 0.611) < 0.03, "SK2 Q");
}

// Messe Pegel am Ausgang fuer einen 1-kHz-Sinus durch die ganze Schaltung (MIX=1)
static double chainGainDb(double ampVolt, double delayKnob, double freq = 1000.0, double* delayMsOut = nullptr)
{
    const double fs = 48000;
    Channel ch; Params p; p.gain = 0.0; p.mix = 1.0; p.delay = delayKnob; p.dev = 0.0; p.mod = 0.0;
    ch.setParams(p); ch.prepare(fs, 1);
    const size_t N = (size_t)(fs * 2.5);
    std::vector<double> y(N);
    for (size_t i = 0; i < N; ++i) y[i] = ch.process(ampVolt * std::sin(2 * kPi * freq * i / fs));
    if (delayMsOut) *delayMsOut = ch.lastDelayMs;
    const double rIn = ampVolt / std::sqrt(2.0);
    return 20 * std::log10(rmsOf(y, (size_t)(fs * 1.5), N) / rIn);
}

static void testCompander()
{
    std::printf("[2] Gesamtketten-Verstaerkung bei 1 kHz (DELAY=0, MIX=1)\n");
    for (double a : { 0.003, 0.01, 0.03, 0.1, 0.3, 0.9 })
    {
        const double g = chainGainDb(a, 0.0);
        std::printf("  Eingang %6.1f dBV -> Gain %+5.2f dB\n", 20 * std::log10(a / std::sqrt(2.0)), g);
        if (a >= 0.03) CHECK(std::fabs(g - 1.2) < 2.5, "Gain bei %.3f V ausserhalb +-2.5 dB um +1.2", a);
    }
    std::printf("  Frequenzgang (0.1 V):\n");
    for (double f : { 50.0, 100.0, 300.0, 1000.0, 3000.0, 6000.0, 10000.0, 14000.0 })
        std::printf("    %6.0f Hz: %+5.2f dB\n", f, chainGainDb(0.1, 0.0, f));
}

static void testDelay()
{
    std::printf("[3] Delay-Zeit (MN3005: 2048 / fclk)\n");
    const double fs = 48000;
    for (double d : { 0.0, 0.2, 0.4, 0.6 })
    {
        Channel ch; Params p; p.gain = 0; p.mix = 1.0; p.delay = d; p.dev = 0.0; p.mod = 0.0;
        ch.setParams(p); ch.prepare(fs, 2);
        const size_t N = (size_t)(fs * 1.2), burstAt = (size_t)(fs * 0.1);
        std::vector<double> y(N), x(N, 0.0);
        const int bl = (int)(0.006 * fs);
        for (int i = 0; i < bl; ++i)
            x[burstAt + i] = 0.3 * std::sin(2 * kPi * 1000.0 * i / fs) * (0.5 - 0.5 * std::cos(2 * kPi * i / bl));
        for (size_t i = 0; i < N; ++i) y[i] = ch.process(x[i]);
        // Huellkurve der Ausgabe suchen (nach dem Burst, um den Direktanteil bei MIX=1 auszuschliessen)
        size_t best = 0; double bestV = 0;
        const size_t smoothN = (size_t)(0.003 * fs);
        for (size_t i = burstAt + bl; i + smoothN < N; ++i)
        {
            double s = 0; for (size_t k = 0; k < smoothN; ++k) s += std::fabs(y[i + k]);
            if (s > bestV) { bestV = s; best = i + smoothN / 2; }
        }
        const double measMs = ((double)best - (double)(burstAt + bl / 2)) / fs * 1000.0;
        std::printf("  DELAY %.1f: erwartet %.1f ms (+ Filterlaufzeit ~0.2 ms), gemessen %.1f ms\n", d, ch.lastDelayMs, measMs);
        CHECK(std::fabs(measMs - ch.lastDelayMs) < 0.04 * ch.lastDelayMs + 1.0, "Delay-Abweichung zu gross");
    }
}

static double lfoFreq(double mod, double dev, double fs, double& vcMin, double& vcMax)
{
    Lfo l; l.setParams(mod, dev);
    const double dt = 1.0 / fs; bool prev = l.high; double last = -1, sum = 0; int n = 0;
    vcMin = 1e9; vcMax = -1e9;
    const long steps = (long)(fs * 14);
    for (long i = 0; i < steps; ++i)
    {
        const double vc = l.process(dt); const double t = i * dt;
        if (t > 5) { vcMin = std::min(vcMin, vc); vcMax = std::max(vcMax, vc); }
        if (l.high && !prev && t > 4) { if (last > 0) { sum += t - last; ++n; } last = t; }
        prev = l.high;
    }
    return n ? 1.0 / (sum / n) : 0.0;
}

static void testLfo()
{
    std::printf("[4] LFO gegen Vollsimulation (volles Modell: 1.185 / 2.350 / 5.075 / 14.005 / 34.834 Hz)\n");
    const double ref[5] = { 1.185, 2.350, 5.075, 14.005, 34.834 };
    int k = 0;
    for (double m : { 0.0, 0.25, 0.5, 0.75, 1.0 })
    {
        double lo, hi; const double f = lfoFreq(m, 0.5, 48000, lo, hi);
        std::printf("  MOD %.2f: %7.3f Hz (Ref %.3f) VC %.3f..%.3f\n", m, f, ref[k], lo, hi);
        CHECK(std::fabs(f / ref[k] - 1.0) < 0.06, "LFO-Frequenz weicht >6%% ab");
        ++k;
    }
    std::printf("  DEV-Sweep bei MOD 0.5 (Vollsim VC: 4.055-4.059 / 4.600-4.732 / 4.895-5.070 / 4.915-5.172 / 4.590-5.074)\n");
    for (double d : { 0.0, 0.25, 0.5, 0.75, 1.0 })
    {
        double lo, hi; lfoFreq(0.5, d, 48000, lo, hi);
        std::printf("  DEV %.2f: VC %.3f..%.3f\n", d, lo, hi);
    }
}

static void testStability()
{
    std::printf("[5] Stabilitaet (Rauschen, Extremwerte, mehrere Abtastraten)\n");
    for (double fs : { 44100.0, 48000.0, 96000.0 })
        for (double g : { 0.0, 1.0 })
            for (double d : { 0.0, 1.0 })
            {
                Channel ch; Params p; p.gain = g; p.mix = 0.5; p.delay = d; p.dev = 1.0; p.mod = 1.0; p.levelDb = 6;
                ch.setParams(p); ch.prepare(fs, 3);
                Rng r; double peak = 0; bool bad = false;
                for (long i = 0; i < (long)(fs * 8); ++i)
                {
                    const double y = ch.process(0.5 * r.uniform());
                    if (!std::isfinite(y)) bad = true;
                    peak = std::max(peak, std::fabs(y));
                }
                CHECK(!bad && peak <= 1.0001, "fs=%.0f gain=%.0f delay=%.0f: NaN oder Peak %.3f", fs, g, d, peak);
            }
    std::printf("  ok\n");
}

int main()
{
    testFilters(); testCompander(); testDelay(); testLfo(); testStability();
    std::printf("\n%s (%d Fehler)\n", failures ? "FEHLGESCHLAGEN" : "ALLE TESTS BESTANDEN", failures);
    return failures ? 1 : 0;
}
