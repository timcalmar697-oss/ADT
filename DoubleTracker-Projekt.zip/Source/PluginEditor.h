#pragma once
#include "PluginProcessor.h"

class DoubleTrackerEditor : public juce::AudioProcessorEditor
{
public:
    explicit DoubleTrackerEditor(DoubleTrackerProcessor&);
    ~DoubleTrackerEditor() override = default;

    void paint(juce::Graphics&) override;
    void resized() override;

private:
    struct Knob
    {
        juce::Slider slider;
        juce::Label label;
        std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> attachment;
    };

    void addKnob(Knob& k, DoubleTrackerProcessor& p, const juce::String& paramId, const juce::String& text);

    Knob gain, mix, delay, dev, mod, level;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(DoubleTrackerEditor)
};
