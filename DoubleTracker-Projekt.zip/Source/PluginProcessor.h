#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include "ADTDsp.h"

class DoubleTrackerProcessor : public juce::AudioProcessor
{
public:
    DoubleTrackerProcessor();
    ~DoubleTrackerProcessor() override = default;

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported(const BusesLayout& layouts) const override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "Double Tracker"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    double getTailLengthSeconds() const override { return 0.6; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return {}; }
    void changeProgramName(int, const juce::String&) override {}

    void getStateInformation(juce::MemoryBlock& destData) override;
    void setStateInformation(const void* data, int sizeInBytes) override;

    juce::AudioProcessorValueTreeState apvts;

private:
    static juce::AudioProcessorValueTreeState::ParameterLayout createLayout();

    adt::Channel channels[2];
    std::atomic<float>* pGain = nullptr;
    std::atomic<float>* pMix = nullptr;
    std::atomic<float>* pDelay = nullptr;
    std::atomic<float>* pDev = nullptr;
    std::atomic<float>* pMod = nullptr;
    std::atomic<float>* pLevel = nullptr;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(DoubleTrackerProcessor)
};
