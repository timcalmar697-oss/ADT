// ADTDsp.h - verhaltensbasiertes Modell des "Bell Automatic Double Tracker"
// Header-only, ohne JUCE-Abhaengigkeit (damit separat testbar).
//
// Signalfluss (nach Schaltplan):
//   Eingang -> U2 (LM741, Gain) -> [Direktsignal]
//                               -> Pre-Emphasis (R6/C7) -> NE571 Kompressor (2:1)
//                               -> Anti-Aliasing (2x Sallen-Key mit Q4/Q7)
//                               -> MN3005 BBD (4096 Stufen, Takt aus CD4046 + LFO U6)
//                               -> Rekonstruktion (2x Sallen-Key mit Q8/Q6)
//                               -> NE571 Expander (1:2) -> De-Emphasis (R21/C21)
//   MIX-Poti: Ueberblendung Direkt <-> Delay
//
// Alle Bauteilwerte stehen als Konstanten oben im jeweiligen Block.
#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <vector>

namespace adt
{
constexpr double kPi = 3.14159265358979323846;

// ---------------------------------------------------------------- Filter

struct Biquad
{
    double b0 = 1, b1 = 0, b2 = 0, a1 = 0, a2 = 0, z1 = 0, z2 = 0;

    void setLowpass(double f0, double Q, double fs)
    {
        f0 = std::min(f0, 0.45 * fs);
        const double w0 = 2.0 * kPi * f0 / fs;
        const double c = std::cos(w0), alpha = std::sin(w0) / (2.0 * Q);
        const double a0 = 1.0 + alpha;
        b0 = (1.0 - c) * 0.5 / a0;
        b1 = (1.0 - c) / a0;
        b2 = b0;
        a1 = -2.0 * c / a0;
        a2 = (1.0 - alpha) / a0;
    }
    // Unity-gain Sallen-Key Tiefpass: R1,R2 in Reihe, c1 = Rueckkopplungs-C (Mitte -> Ausgang),
    // c2 = C nach Masse.  H(s) = 1 / (s^2 R1 R2 C1 C2 + s C2 (R1+R2) + 1)
    void setSallenKey(double r1, double r2, double c1, double c2, double fs)
    {
        const double w0 = 1.0 / std::sqrt(r1 * r2 * c1 * c2);
        const double Q = std::sqrt(r1 * r2 * c1 * c2) / (c2 * (r1 + r2));
        setLowpass(w0 / (2.0 * kPi), Q, fs);
    }
    double process(double x)
    {
        const double y = b0 * x + z1;
        z1 = b1 * x - a1 * y + z2;
        z2 = b2 * x - a2 * y;
        return y;
    }
    void reset() { z1 = z2 = 0; }
};

// Allgemeines Filter 1. Ordnung, H(s) = g0 (1 + s tz) / (1 + s tp), bilinear transformiert
struct FirstOrder
{
    double b0 = 1, b1 = 0, a1 = 0, z = 0;

    void setShelf(double g0, double tz, double tp, double fs)
    {
        const double K = 2.0 * fs;
        const double a0 = 1.0 + K * tp;
        b0 = g0 * (1.0 + K * tz) / a0;
        b1 = g0 * (1.0 - K * tz) / a0;
        a1 = (1.0 - K * tp) / a0;
    }
    void setHighpass(double fc, double fs) { setShelfHP(1.0 / (2.0 * kPi * fc), fs); }
    void setHighpassTau(double tau, double fs) { setShelfHP(tau, fs); }
    void setLowpassTau(double tau, double fs)
    {
        const double K = 2.0 * fs;
        const double a0 = 1.0 + K * tau;
        b0 = b1 = 1.0 / a0;
        a1 = (1.0 - K * tau) / a0;
    }
    double process(double x)
    {
        const double y = b0 * x + z;
        z = b1 * x - a1 * y;
        return y;
    }
    void reset() { z = 0; }

private:
    void setShelfHP(double tau, double fs)
    {
        const double K = 2.0 * fs;
        const double a0 = 1.0 + K * tau;
        b0 = K * tau / a0;
        b1 = -b0;
        a1 = (1.0 - K * tau) / a0;
    }
};

// ---------------------------------------------------------------- Hilfsfunktionen

inline double softClipAsym(double x, double vPos, double vNeg)
{
    return x >= 0.0 ? vPos * std::tanh(x / vPos) : -vNeg * std::tanh(-x / vNeg);
}

// Weiche Begrenzung fuer den Plugin-Ausgang (digital, Vollaussteuerung = 1.0)
inline double softLimit(double x)
{
    const double knee = 0.9, a = std::fabs(x);
    if (a <= knee) return x;
    const double y = knee + (1.0 - knee) * std::tanh((a - knee) / (1.0 - knee));
    return x < 0 ? -y : y;
}

struct Rng
{
    uint32_t s = 0x12345678u;
    double uniform() // -1..1
    {
        s ^= s << 13; s ^= s >> 17; s ^= s << 5;
        return (double)s / 2147483648.0 - 1.0;
    }
    double gauss() { return (uniform() + uniform() + uniform() + uniform()) * 0.8660254; } // ~ sigma 1
};

inline double lerp(double a, double b, double t) { return a + (b - a) * t; }

// ---------------------------------------------------------------- LFO + VCO-Eingang (U6, DEV-Netzwerk, CD4046 Pin 9)

struct Lfo
{
    // Bauteile (Schaltplan)
    static constexpr double R46 = 330e3, R52 = 150e3, R47 = 2.7e3, R54 = 33e3, R50 = 100e3, R51 = 270e3;
    static constexpr double C39 = 4.7e-6, C37 = 10e-6, Vdd = 15.0;
    static constexpr double Vh = 12.7, Vl = -10.0; // LM741-Ausgangshub (Vb ~ +14.7 V, -12 V)

    bool high = true;
    double N = 0.0;  // Spannung an C39 (Zeitgeberknoten)
    double W = 4.0;  // Schleifer des DEV-Potis (C37)
    double ra = R47 + 50e3, rup = 50e3, rdn = 50e3, tscale = 1.0;

    // mod/dev: Potistellung 0..1.  MOD: Knopf hoch = schneller (Rheostat, log), DEV: linear
    void setParams(double mod, double dev)
    {
        mod = std::clamp(mod, 0.0, 1.0);
        dev = std::clamp(dev, 0.0, 1.0);
        const double rmod = std::max(100.0, 100e3 * (1.0 - mod) * (1.0 - mod));
        ra = R47 + rmod;
        rup = std::max(100.0, (1.0 - dev) * 100e3);
        rdn = std::max(100.0, dev * 100e3);
        // Zeitkorrektur: reduziertes Modell (ohne C36/Op-Amp-Dynamik) -> Frequenz der
        // Vollsimulation (siehe Test).  Stuetzstellen bei MOD = 0, .25, .5, .75, 1
        static const double knots[5] = { 0.968, 0.944, 0.895, 0.777, 0.602 };
        const double p = mod * 4.0;
        const int i = std::min(3, (int)p);
        tscale = lerp(knots[i], knots[i + 1], p - i);
    }

    // liefert die VCO-Eingangsspannung (Volt) fuer einen Zeitschritt dt
    double process(double dt)
    {
        const double beta = R52 / (R46 + R52);
        const double Vo = high ? Vh : Vl;
        const double M = (N / R54 + W / rup) / (1.0 / R54 + 1.0 / rup);
        const double VC = (W / R50 + Vdd / R51) / (1.0 / R50 + 1.0 / R51);
        N += ((Vo - N) / ra + (M - N) / R54) / C39 * dt * tscale;
        W += ((M - W) / rup - W / rdn - (W - VC) / R50) / C37 * dt;
        if (high && N > beta * Vh) high = false;
        else if (!high && N < beta * Vl) high = true;
        return VC;
    }
};

// CD4046-VCO: f = (Vin/Vdd) / (k * R1 * (C1 + Cpar)).  k und Cpar sind aus dem Datenblatt
// grob abgeschaetzt (nicht gemessen) -> hier ist die Hauptunsicherheit der Delay-Zeit.
struct Vco
{
    static constexpr double R55 = 4.7e3, C38 = 220e-12, Cpar = 32e-12, k = 2.2, Vdd = 15.0;
    static double r1FromKnob(double delayKnob) // DELAY: A100K (log), in Reihe zu R55
    {
        delayKnob = std::clamp(delayKnob, 0.0, 1.0);
        return R55 + 100e3 * delayKnob * delayKnob;
    }
    static double clockHz(double vin, double r1)
    {
        const double f = (vin / Vdd) / (k * r1 * (C38 + Cpar));
        return std::clamp(f, 4e3, 100e3); // MN3005: Takt bis 100 kHz
    }
};

// ---------------------------------------------------------------- BBD MN3005 (4096 Stufen)

struct Bbd
{
    static constexpr int kStages = 4096;           // Eimer (Stufen)
    static constexpr int kSamples = kStages / 2;   // pro Abtastwert werden 2 Stufen belegt
    std::vector<double> buf;
    int pos = 0;
    double acc = 0.0, hold = 0.0, prevIn = 0.0;
    bool parity = false;
    double satVolt = 4.5;     // Annahme: Eingangsuebersteuerung ~4.5 V
    double clockFeed = 1e-3;  // Annahme: Taktdurchschlag ~1 mV

    void prepare() { buf.assign(kSamples, 0.0); pos = 0; acc = 0; hold = 0; prevIn = 0; }

    // fclk = Taktfrequenz (Hz) = Abtastrate; 4096 Stufen halten 2048 Abtastwerte,
    // Verzoegerung = 4096 / (2 fclk) = 2048 / fclk  (MN3005-Datenblatt: 20 ms .. 205 ms bei 100 .. 10 kHz)
    double process(double in, double fclk, double fs)
    {
        const double x = satVolt * std::tanh(in / satVolt);
        const double ticksPerSample = fclk / fs;
        const double accBefore = acc;
        const double total = accBefore + ticksPerSample;
        const int n = (int)total;
        for (int j = 1; j <= n; ++j)
        {
            const double t = (j - accBefore) / ticksPerSample;
            buf[pos] = prevIn + (x - prevIn) * t;
            pos = (pos + 1) % kSamples;
            hold = buf[pos]; // aeltester Wert = vor 4096 Taktschritten geschrieben
            parity = !parity;
        }
        acc = total - n;
        prevIn = x;
        return hold + (parity ? clockFeed : -clockFeed);
    }
};

// ---------------------------------------------------------------- Kanal (komplette Schaltung)

struct Params
{
    double gain = 0.1, mix = 0.5, delay = 0.2, dev = 0.5, mod = 0.5; // alle 0..1 (Potistellungen)
    double levelDb = 0.0;                                           // Ausgangspegel (nicht im Original)
};

struct Channel
{
    // ---- Bauteilwerte
    static constexpr double R1_in = 470e3, C1_in = 30e-9;     // Eingangs-Hochpass
    static constexpr double R4 = 1e3, C3 = 10e-6;             // Gain-Zweig an U2
    static constexpr double RgainPot = 100e3, GBW = 1e6;      // GAIN A100K, LM741
    static constexpr double vPos = 12.7, vNeg = 10.0;         // U2 Ausgangshub
    static constexpr double R6 = 33e3, C7 = 3.3e-9, R3int = 10e3; // Pre-Emphasis
    static constexpr double R21 = 47e3, C21 = 3.3e-9;         // De-Emphasis (Expander-Rueckkopplung)
    static constexpr double V0 = 0.698;                       // NE571 0 dB: 0.775 Vrms -> Mittelwert 0.698 V
    static constexpr double tauAttack = 3e-3, tauRelease = 10e-3; // Gleichrichter (C11/C19 = 1 uF)
    static constexpr double noiseRms = 0.4e-3;                // Annahme BBD-Rauschen

    double fs = 48000.0, dt = 1.0 / 48000.0;
    Params p, sm; // Ziel / geglaettet
    double smoothCoef = 0.0;

    FirstOrder hpIn, hpGain, lpGbw, preEmph, hpAA, hpRec, deEmph, dcOut;
    Biquad aa1, aa2, rec1, rec2;
    Bbd bbd;
    Lfo lfo;
    Rng rng;
    double envC = 0, envE = 0, attackCoef = 0, releaseCoef = 0;
    double lastFclk = 0, lastDelayMs = 0;

    void prepare(double sampleRate, uint32_t seed)
    {
        fs = sampleRate;
        dt = 1.0 / fs;
        smoothCoef = 1.0 - std::exp(-1.0 / (0.03 * fs));
        hpIn.setHighpassTau(R1_in * C1_in, fs);
        hpGain.setHighpassTau(R4 * C3, fs);
        preEmph.setShelf(R3int / (R3int + R6), R6 * C7, (R6 * R3int / (R6 + R3int)) * C7, fs);
        deEmph.setShelf((R3int + R21) / R3int, R21 * C21 * R3int / (R3int + R21), R21 * C21, fs);
        hpAA.setHighpassTau(47e3 * 100e-9, fs);     // C13 / R13
        hpRec.setHighpassTau(100e3 * 100e-9, fs);   // C34 / R34
        dcOut.setHighpassTau((15e3 + 470e3) * 10e-6, fs); // C9 / (R8+R9)
        // Anti-Aliasing (Q4, Q7) und Rekonstruktion (Q8, Q6): identische Sallen-Key-Stufen
        aa1.setSallenKey(33e3, 33e3, 660e-12, 220e-12, fs);
        aa2.setSallenKey(33e3, 33e3, 330e-12, 220e-12, fs);
        rec1.setSallenKey(33e3, 33e3, 660e-12, 220e-12, fs);
        rec2.setSallenKey(33e3, 33e3, 330e-12, 220e-12, fs);
        attackCoef = 1.0 - std::exp(-1.0 / (tauAttack * fs));
        releaseCoef = 1.0 - std::exp(-1.0 / (tauRelease * fs));
        bbd.prepare();
        rng.s = 0x9E3779B9u ^ seed;
        sm = p;
        lfo.setParams(sm.mod, sm.dev);
        reset();
    }

    void reset()
    {
        for (auto* f : { &hpIn, &hpGain, &lpGbw, &preEmph, &hpAA, &hpRec, &deEmph, &dcOut }) f->reset();
        for (auto* b : { &aa1, &aa2, &rec1, &rec2 }) b->reset();
        envC = envE = 0;
        bbd.prepare();
    }

    void setParams(const Params& np) { p = np; }

    static double rect(double x, double& env, double ca, double cr)
    {
        const double a = std::fabs(x);
        env += (a - env) * (a > env ? ca : cr);
        return env;
    }

    // Eingang/Ausgang: digital (1.0 = 1 V Referenz)
    double process(double xin)
    {
        // Parameter glaetten (Poti wird nicht schlagartig bewegt)
        sm.gain += (p.gain - sm.gain) * smoothCoef;
        sm.mix += (p.mix - sm.mix) * smoothCoef;
        sm.delay += (p.delay - sm.delay) * smoothCoef;
        sm.dev += (p.dev - sm.dev) * smoothCoef;
        sm.mod += (p.mod - sm.mod) * smoothCoef;

        // ---- U2: Eingang und Gain-Stufe
        const double rf = RgainPot * sm.gain * sm.gain;
        const double gHF = 1.0 + rf / R4;
        double v = hpIn.process(xin);
        v = v + (rf / R4) * hpGain.process(v);          // 1 + Rf/(R4 + 1/(s C3))
        lpGbw.setLowpassTau(1.0 / (2.0 * kPi * std::min(GBW / gHF, 0.45 * fs)), fs); // GBW/Verstaerkung
        v = lpGbw.process(v);
        const double direct = softClipAsym(v, vPos, vNeg);

        // ---- Pre-Emphasis + Kompressor (NE571 Kanal 1, 2:1)
        const double pre = preEmph.process(direct);
        const double eC = rect(pre, envC, attackCoef, releaseCoef);
        const double gC = std::sqrt(V0 / (eC + 1e-5));
        double c = pre * gC;

        // ---- Anti-Aliasing -> BBD
        c = aa2.process(aa1.process(hpAA.process(c)));
        const double vin = lfo.process(dt);
        lfo.setParams(sm.mod, sm.dev);
        const double r1 = Vco::r1FromKnob(sm.delay);
        const double fclk = Vco::clockHz(vin, r1);
        lastFclk = fclk;
        lastDelayMs = 2048.0 / fclk * 1000.0;
        double b = bbd.process(c, fclk, fs);
        b += noiseRms * rng.gauss();

        // ---- Rekonstruktion -> Expander (1:2) -> De-Emphasis
        double r = rec2.process(rec1.process(hpRec.process(b)));
        const double eE = rect(r, envE, attackCoef, releaseCoef);
        const double gE = eE / V0;
        const double delayed = deEmph.process(r * gE);

        // ---- MIX-Poti: Ueberblendung der beiden niederohmigen Quellen
        double mixed = (1.0 - sm.mix) * direct + sm.mix * delayed;
        mixed = dcOut.process(mixed);
        const double level = std::pow(10.0, p.levelDb / 20.0);
        return softLimit(mixed * level);
    }
};

} // namespace adt
