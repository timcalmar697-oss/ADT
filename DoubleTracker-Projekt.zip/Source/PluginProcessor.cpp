#include "PluginProcessor.h"
#include "PluginEditor.h"

juce::AudioProcessorValueTreeState::ParameterLayout DoubleTrackerProcessor::createLayout()
{
    using P = juce::AudioParameterFloat;
    juce::AudioProcessorValueTreeState::ParameterLayout layout;
    const auto range01 = juce::NormalisableRange<float>(0.0f, 1.0f, 0.001f);
    // Potistellungen 0..1 wie am Original (GAIN/DELAY/MOD: log, MIX/DEV: linear - das ist im DSP abgebildet)
    layout.add(std::make_unique<P>(juce::ParameterID{ "gain", 1 }, "Gain", range01, 0.1f));
    layout.add(std::make_unique<P>(juce::ParameterID{ "mix", 1 }, "Mix", range01, 0.5f));
    layout.add(std::make_unique<P>(juce::ParameterID{ "delay", 1 }, "Delay", range01, 0.2f));
    layout.add(std::make_unique<P>(juce::ParameterID{ "dev", 1 }, "Dev", range01, 0.5f));
    layout.add(std::make_unique<P>(juce::ParameterID{ "mod", 1 }, "Mod", range01, 0.5f));
    layout.add(std::make_unique<P>(juce::ParameterID{ "level", 1 }, "Level",
                                   juce::NormalisableRange<float>(-30.0f, 12.0f, 0.1f), 0.0f,
                                   juce::AudioParameterFloatAttributes().withLabel("dB")));
    return layout;
}

DoubleTrackerProcessor::DoubleTrackerProcessor()
    : AudioProcessor(BusesProperties()
                         .withInput("Input", juce::AudioChannelSet::stereo(), true)
                         .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      apvts(*this, nullptr, "PARAMS", createLayout())
{
    pGain = apvts.getRawParameterValue("gain");
    pMix = apvts.getRawParameterValue("mix");
    pDelay = apvts.getRawParameterValue("delay");
    pDev = apvts.getRawParameterValue("dev");
    pMod = apvts.getRawParameterValue("mod");
    pLevel = apvts.getRawParameterValue("level");
}

bool DoubleTrackerProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const
{
    const auto in = layouts.getMainInputChannelSet();
    const auto out = layouts.getMainOutputChannelSet();
    if (out != juce::AudioChannelSet::mono() && out != juce::AudioChannelSet::stereo())
        return false;
    return in == out;
}

void DoubleTrackerProcessor::prepareToPlay(double sampleRate, int)
{
    for (int c = 0; c < 2; ++c)
    {
        channels[c].prepare(sampleRate, (uint32_t) (c + 1));
    }
}

void DoubleTrackerProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;
    const int numCh = juce::jmin(buffer.getNumChannels(), 2);
    const int numSamples = buffer.getNumSamples();

    adt::Params p;
    p.gain = *pGain;
    p.mix = *pMix;
    p.delay = *pDelay;
    p.dev = *pDev;
    p.mod = *pMod;
    p.levelDb = *pLevel;

    for (int c = 0; c < numCh; ++c)
    {
        channels[c].setParams(p);
        float* data = buffer.getWritePointer(c);
        for (int i = 0; i < numSamples; ++i)
            data[i] = (float) channels[c].process((double) data[i]);
    }
    for (int c = numCh; c < buffer.getNumChannels(); ++c)
        buffer.clear(c, 0, numSamples);
}

juce::AudioProcessorEditor* DoubleTrackerProcessor::createEditor()
{
    return new DoubleTrackerEditor(*this);
}

void DoubleTrackerProcessor::getStateInformation(juce::MemoryBlock& destData)
{
    if (auto xml = apvts.copyState().createXml())
        copyXmlToBinary(*xml, destData);
}

void DoubleTrackerProcessor::setStateInformation(const void* data, int sizeInBytes)
{
    if (auto xml = getXmlFromBinary(data, sizeInBytes))
        if (xml->hasTagName(apvts.state.getType()))
            apvts.replaceState(juce::ValueTree::fromXml(*xml));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new DoubleTrackerProcessor();
}
