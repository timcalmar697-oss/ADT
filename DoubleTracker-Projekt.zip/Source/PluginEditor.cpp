#include "PluginEditor.h"

DoubleTrackerEditor::DoubleTrackerEditor(DoubleTrackerProcessor& p) : AudioProcessorEditor(&p)
{
    addKnob(gain, p, "gain", "GAIN");
    addKnob(mix, p, "mix", "MIX");
    addKnob(delay, p, "delay", "DELAY");
    addKnob(dev, p, "dev", "DEV");
    addKnob(mod, p, "mod", "MOD");
    addKnob(level, p, "level", "LEVEL");
    setSize(640, 260);
}

void DoubleTrackerEditor::addKnob(Knob& k, DoubleTrackerProcessor& p, const juce::String& paramId, const juce::String& text)
{
    k.slider.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
    k.slider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 70, 18);
    k.slider.setColour(juce::Slider::rotarySliderFillColourId, juce::Colour(0xffd9a441));
    k.slider.setColour(juce::Slider::thumbColourId, juce::Colour(0xfff2e6c9));
    k.label.setText(text, juce::dontSendNotification);
    k.label.setJustificationType(juce::Justification::centred);
    k.label.setColour(juce::Label::textColourId, juce::Colour(0xfff2e6c9));
    k.label.setFont(juce::FontOptions(15.0f, juce::Font::bold));
    addAndMakeVisible(k.slider);
    addAndMakeVisible(k.label);
    k.attachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(p.apvts, paramId, k.slider);
}

void DoubleTrackerEditor::paint(juce::Graphics& g)
{
    g.fillAll(juce::Colour(0xff2b2622));
    g.setColour(juce::Colour(0xfff2e6c9));
    g.setFont(juce::FontOptions(22.0f, juce::Font::bold));
    g.drawText("AUTOMATIC DOUBLE TRACKER", getLocalBounds().removeFromTop(44), juce::Justification::centred);
}

void DoubleTrackerEditor::resized()
{
    auto area = getLocalBounds().reduced(14);
    area.removeFromTop(40);
    const int w = area.getWidth() / 6;
    for (auto* k : { &gain, &mix, &delay, &dev, &mod, &level })
    {
        auto col = area.removeFromLeft(w);
        k->label.setBounds(col.removeFromTop(22));
        k->slider.setBounds(col);
    }
}
